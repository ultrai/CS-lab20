clc;
clear all;
close all;
num=[9];
den=[1 2 9];
sys=tf(num,den)
step(sys,0:.01:10);
title('step response of system');
[r,p,c]=residue(num,den)