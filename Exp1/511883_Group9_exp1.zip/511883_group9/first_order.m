R=3;
u = 2;
s = tf('s');
G = 1/(s+R);
step(u*G)
figure(2)
impulse(u*G)
figure(3)
step(u*G/s)
F = 5/(8*s+1);
figure(4)
step(u*F)









% figure(2)
% title("Second figure")
% G = 1/(s+R);
% plot(step(u*G))
% figure(3)
% G = 1/(s+(5*R));
% plot(step(u*G))