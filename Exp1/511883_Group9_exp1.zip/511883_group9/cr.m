clc;
clear;
num=[1];
den=[1 2 1];
sys=tf(num,den)
step(sys,0:.01:10);
title('step response of system');
[r,p,c]=residue(num,den)
Damping_ratio=den(2)/(2*sqrt(den(3)))