R=3;
zeros=[1;2];
poles=[2;R;4];
[n,d]=zp2tf(zeros,poles,1);
sys=tf(n,d)
step(sys);
title('step response of system');
[r,p,c]=residue(n,d)