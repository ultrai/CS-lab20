clc;
clear all;
close all;
num=[8];
den=[1 3 8];
sys=tf(num,den)
step(sys,0:.01:10);
title('step response of system');
[r,p,c]=residue(num,den)
Damping_ratio=den(2)/(2*sqrt(den(3)))